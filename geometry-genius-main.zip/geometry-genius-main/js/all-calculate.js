function allField(elementId) {
    const allField = document.getElementById(elementId);
    const allFieldValue = allField.value;
    allField.value = '';
    return allFieldValue;
}
function allAreaValueSet(elementId) {
    const allArea = document.getElementById(elementId);
    return allArea;
}


